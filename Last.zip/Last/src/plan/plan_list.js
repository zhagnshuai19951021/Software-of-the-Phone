new Vue({
    el: '#planShow',
    data: function () {
        return {
            orgId:orgId,//登录机构
            context:context,//项目的相对路径配置
            planListData:[],//表格的list数据
            currentPage: 1,//当前页码
            fetchNum: 10,//当前页显示条数
            totalPage: '',//数据总条数
            begNum:1,//分页数据:数据库查询的起始位置
            viewDialog: false,//查看信息
            btnShow: true,
            inputShow: false,
            /*搜索值*/
            searchPlanName:'',
            searchOrgStr:'',
            searchPlanYear:'',
            organCodes:'',
            /*数据重复绑定*/
            searchPlanName1:'',
            searchPlanYear1:'',
            organCodes1:'',
            searchOrgImplementationUnitCode1: '',
            searchPlanType1: planTypeInit,
            searchMajorType1: '',
            startTime1: '',
            endTime1:'',

            downLoadloading:'',//导出遮罩层
            /*树形结构*/
            searchOrg:[], //计划制定单位文本值,
            ishowTree: false, //机构树显示
            dataTree:[{
                value: 1,
                label: '一级 1',
                disabled: 1,
                children: [{
                    value: 4,
                    label: '二级 1-1',
                    disabled: 1,
                    children: [{
                        value: 9,
                        label: '三级 1-1-1',
                        disabled: 0
                    }, {
                        value: 10,
                        label: '三级 1-1-2',
                        disabled: 0
                    }]
                }]
            }],
            /*树形结构的值配置的默认配置*/
            defaultProps: {
                children: 'children',
                label: 'label',
                isLeaf: 'leaf'
            },

            planTypeList: planTypeList,
            searchPlanType: planTypeInit,
            startTime: '',
            endTime: '',
            startEndAnnual: [],
            organName: orgName,

            /*table column 排序*/
            customSortProp: '',//排序字段
            customSortOrder: '',//排序规则（descending、ascending）
            planListLoading: false,
            searchOrgImplementationUnit: '',//v-model 计划实施单位label
            ishowTreeImplementationUnit: false,
            searchOrgImplementationUnitCode: '', //计划实施单位id
            majorTypeList: majorTypeList,//审计专业类别
            searchMajorType: '',
            selectionPlanIds: [],//已选择计划
            implementUnitTreeData: []//重置计划实施单位机构树

        }
    },

    /*监听机构单位变化实现节点过滤*/
    watch:{
        searchPlanName (val) {
            this.$nextTick(() => {
                this.searchPlanName = this.filterInput(val);
            })
        }
    },

    /*钩子函数：页面渲染前执行*/
    created () {
        this.reSize();
        this.searchPlanYear = this.getCurrentYear();
        this.searchPlanYear1 = this.searchPlanYear;
        this.searchOrgStr = orgName;
        this.organCodes = orgId;
        this.organCodes1 = orgId;
        this.queryData();
    },

    /*钩子函数：页面加载完成后执行*/
    mounted () {
        document.getElementById("planShow").style.display='block';//页面加载优化
        this.windowResizeEvent(this.reSize);
    },

    methods: {
        /*查询勾选计划已分解项目*/
        toQueryPlanIssuedProjectPage() {
            if(null === this.selectionPlanIds || this.selectionPlanIds.length === 0) {
                vueDialog('请选择至少一项计划',"提示","warning",this,function(){})
                return
            }
            parent.window.mainMenu.addTab('查询勾选计划', '/plan/query/toQueryPlanIssuedProjectPage?selectionPlanIdsStr='
                + this.selectionPlanIds.join(','));
        },

        /*勾选项发生变化时触发事件*/
        handleSelectionChange(val) {
            this.selectionPlanIds = val;
        },

        /*计划单选*/
        handleSelectionChangeOrgan(selection) {
            this.selectionPlanIds = [];
            for (let i in  selection) {
                if (selection.hasOwnProperty(i)) {
                    if (!!selection.hasOwnProperty(i)) {
                        if ('pkPlan' in selection[i] && !!selection[i].pkPlan) {
                            this.selectionPlanIds.push(selection[i].pkPlan)
                        }
                    }
                }
            }
        },

        /*批量计划全选*/
        handleSelectionChangeOrganAll(selection) {
            this.selectionPlanIds = [];
            for (let i in  selection) {
                if (selection.hasOwnProperty(i)) {
                    if (!!selection.hasOwnProperty(i)) {
                        if ('pkPlan' in selection[i] && !!selection[i].pkPlan) {
                            this.selectionPlanIds.push(selection[i].pkPlan)
                        }
                    }
                }
            }
        },


        /*自定义排序 column参数为一个对象包含需要排序的字段(prop)和排序规则(DESC、ASC) 另需要单独定义两个变量绑定这两个值 因为涉及到导出（导出无法直接获取column）*/
        customSortChange(column) {
            // console.log(column)
            this.customSortProp = column.prop
            this.customSortOrder = column.order
            this.queryData()
        },

        startEndAnnualChange() {
            this.startCreateTime = this.startEndAnnual[0]
            this.endCreateTime = this.startEndAnnual[1]
        },

        /*审计计划类别change event*/
        planTypeChangeFun() {
            //重置计划制定单位
            this.searchOrgStr = ''
            this.organCodes = '';
            this.organCodes1 = '';
            this.orgCodeStr = ''
            if (this.searchPlanType == 'PT001') {
                this.searchOrgStr = '审计署'
                this.organCodes = 'orgRootDomain';
                this.organCodes1 = 'orgRootDomain';
            }

            if (!!this.organCodes1) {
                this.resetImplementUnitOrganTree(this.organCodes1)
            } else{
                this.implementUnitTreeData = []
            }
        },

        majorTypeChangeFun() {
            console.log(this.searchMajorType)
        },

        /**/
        resetImplementUnitOrganTree(orgId) {
            axios.post(context + '/plan/query/getBaseOrganInfoImplementationUnit', {
                selectionPlanFormUnitCode: orgId
            }).then(res => {
                if (res.data.resultCode === 200) {
                    this.implementUnitTreeData = res.data.data
                    // resolve(res.data.data)
                } else {
                    // this.implementUnitTreeData = []
                    // resolve([])
                    // this.$message.error(res.data.resultMsg)
                    vueDialog(res.data.resultMsg,"提示","error",this,function(){});
                }
            }).catch(res => {
                // this.$message.error(res.data.resultMsg)
                vueDialog(res.data.resultMsg,"提示","error",this,function(){});
            });
        },

        /*懒加载获取机构（计划实施单位）*/
        getLazyLoadOrganNodeListImplementationUnit(node, resolve) {
            if(node.level === 0){
                this.getBaseOrganInfoImplementationUnit(resolve);
                return;
            }
            if(node.level >= 1){
                this.getChildrenOrganNodeListImplementationUnit(node.data.id, resolve);//非根节点机构，获取当前节点的直接下级子节点机构列表
            }
        },

        /*懒加载获取根节点机构，打开树时展开该机构节点（计划实施单位）*/
        getBaseOrganInfoImplementationUnit (resolve) {
            axios.post(context + '/plan/query/getBaseOrganInfoImplementationUnit', {
                selectionPlanFormUnitCode: this.organCodes1
            }).then(res => {
                if (res.data.resultCode === 200) {
                    resolve(res.data.data)
                } else {
                    resolve([])
                    // this.$message.error(res.data.resultMsg)
                    vueDialog(res.data.resultMsg,"提示","error",this,function(){});
                }
            }).catch(res => {
                // this.$message.error(res.data.resultMsg)
                vueDialog(res.data.resultMsg,"提示","error",this,function(){});
            });
        },

        /*懒加载获取当前节点机构的直接下级子节点层机构列表（计划实施单位）*/
        getChildrenOrganNodeListImplementationUnit (id, resolve) {
            axios.post(context + '/plan/query/getChildrenOrganNodeListImplementationUnit', {
                currentNodeId: id
            }).then(res => {
                if (res.data.resultCode === 200) {
                    resolve(res.data.data)
                }else {
                    resolve([])
                    // this.$message.error(res.data.resultMsg)
                    vueDialog(res.data.resultMsg,"提示","error",this,function(){});
                }
            }).catch(res => {
                // this.$message.error(res.data.resultMsg)
                vueDialog(res.data.resultMsg,"提示","error",this,function(){});
            })
        },

        /*懒加载获取机构（计划制定单位）*/
        getLazyLoadOrganNodeList (node, resolve){
            if(node.level === 0){
                this.getBaseOrganInfo(resolve);//获取根节点结构
                return;
            }
            if(node.level >= 1){
                this.getChildrenOrganNodeList(node.data.id, resolve);//非根节点机构，获取当前节点的直接下级子节点机构列表
            }
        },

        /*懒加载获取根节点机构，打开树时展开该机构节点（计划制定单位）*/
        getBaseOrganInfo (resolve) {
            axios.post(context + '/plan/query/getBaseOrganInfo', {}).then(res => {
                if (res.data.resultCode === 200) {
                    resolve(res.data.data)
                } else {
                    resolve([])
                    // this.$message.error(res.data.resultMsg)
                    vueDialog(res.data.resultMsg,"提示","error",this,function(){});
                }
            }).catch(res => {
                // this.$message.error(res.data.resultMsg)
                vueDialog(res.data.resultMsg,"提示","error",this,function(){});
            });
        },

        /*懒加载获取当前节点机构的直接下级子节点层机构列表（计划制定单位）*/
        getChildrenOrganNodeList (id, resolve) {
            axios.post(context + '/plan/query/getChildrenOrganNodeList', {
                currentNodeId: id
            }).then(res => {
                if (res.data.resultCode === 200) {
                    resolve(res.data.data)
                }else {
                    resolve([])
                    // this.$message.error(res.data.resultMsg)
                    vueDialog(res.data.resultMsg,"提示","error",this,function(){});
                }
            }).catch(res => {
                // this.$message.error(res.data.resultMsg)
                vueDialog(res.data.resultMsg,"提示","error",this,function(){});
            })
        },

        /*编辑计划自然年度事件*/
        editYear (row) {
            row.btnShow = false;
            row.inputShow = true;
        },

        /*保存（修改计划自然年度）*/
        saveYear (row) {
            if(!row.currentOrganAnnual){
                // this.$message.error('计划自然审计年度不允许为空')
                vueDialog('计划自然审计年度不允许为空',"提示","error",this,function(){});
                return
            }
            axios.post(context + '/plan/query/setUpCivilAnnual', {
                currentOrganAnnual: row.currentOrganAnnual,
                formUnit: row.formUnit,
                planId: row.pkPlan
            }).then(res => {
                if (res.data.resultCode === 200)
                // this.$message.success(res.data.resultMsg)
                    vueDialog(res.data.resultMsg,"提示","success",this,function(){});
            }).catch(res => {
                // this.$message.error(res.data.resultMsg)
                vueDialog(res.data.resultMsg,"提示","error",this,function(){});
            })
            row.btnShow = true;
            row.inputShow = false;
        },

        changeNameFunImplementationUnit(){
            this.ishowTreeImplementationUnit = true;
        },


        changeNameFun(){
            this.ishowTree = true;
        },

        /*文本拦截验证*/
        filterInput(val){
            return val.replace(/[^（）—a-zA-Z0-9\u4E00-\u9FA5]/,'');
        },

        /*节点过滤*/
        filterNode (value, data) {
            if(!value){
                return true;
            }
            return data.label.indexOf(value) !== -1;
        },

        /*监听元素大小改变事件*/
        windowResizeEvent (callback) {
            let resizeTimer = null;
            window.onresize = () => {
                if(resizeTimer === null) {
                    resizeTimer = setTimeout(() => {
                        resizeTimer = null;
                        callback();
                    }, 200);
                }
            }
        },

        /*元素大小改变*/
        reSize() {
            this.$nextTick(() => {
                var tableW = this.$refs.planListTb1.$el.offsetWidth;
            })
        },

        clearSearchOrg () {
            this.organCodes = '';
            this.organCodes1 = '';
            this.searchOrgStr = '';
        },

        /*清空机构Ids*/
        clearSearchOrgImplementationUnit () {
            // this.organCodes = '';
            // this.organCodes1 = '';
            this.searchOrgImplementationUnitCode = '';
        },

        /*机构树内容改变（计划实施单位）*/
        changeValueImplementationUnit () {
            let orgValue = this.searchOrgImplementationUnit.trim();
            if(orgValue === "" || orgValue === null){
                this.$refs.dataTreeImplementationUnit.setCheckedNodes([]);
            }
        },

        /*机构树内容改变（计划制定单位）*/
        changeValue () {
            let orgValue = this.searchOrgStr.trim();
            if(orgValue === "" || orgValue === null){
                this.$refs.dataTree.setCheckedNodes([]);
            }
        },

        /*树状图勾选事件（计划实施单位）*/
        currentchangeImplementationUnit (data) {
            if (data.label == '审计机构' || data.label == '地方审计机关') {
                return
            }
            if (data.orgScope == 0) {
                return
            }

            this.searchOrgImplementationUnit = data.label
            this.searchOrgImplementationUnitCode = data.id
            this.ishowTreeImplementationUnit = false;
        },


        /*树状图勾选事件（计划制定单位）*/
        currentchange (data) {
            if (data.label == '审计机构' || data.label == '地方审计机关') {
                return
            }
            //筛选虚拟节点
            if(!!data.isLevel){
                return;
            }

            //根据审计计划类别筛选机构
            if (!!data.orgScope) {
                if (this.searchPlanType === 'PT001') {//署统一组织 只能选择审计署
                    if (data.orgScope !== 1) {
                        return
                    }
                }
                if (this.searchPlanType === 'PT002') {//省统一组织 只能选择省、直辖市
                    if (data.orgScope !== 2 ) {
                        return
                    }
                }
                if (this.searchPlanType === 'PT003') {//市统一组织 只能选择市、直辖市的区
                    if (data.orgScope !== 3) {
                        return
                    }
                }
                if (this.searchPlanType === 'PT004') {//县统一组织 只能选择县、市的区
                    if (data.orgScope !== 4) {
                        return
                    }
                }
            }

            this.searchOrg = data.label;
            this.organCodes = data.id;
            this.searchOrgStr = this.searchOrg.toString();
            this.ishowTree = false;

            //联动请求 将该节点当作根节点 重置计划实施单位的机构树
            this.resetImplementUnitOrganTree(this.organCodes)
        },

        /*解决树形弹窗显示BUG: 数据移出输入框或者树形结构弹窗时, 让树形结构弹窗消失*/
        stopOverflowEventImplementationUnit (e) {
            this.ishowTreeImplementationUnit = !this.ishowTreeImplementationUnit;
            let _this = this;
            document.onclick=function(){
                _this.ishowTreeImplementationUnit = false;
                _this.ishowTree = false;
            };
            e.stopPropagation();
        },

        /*解决树形弹窗显示BUG:数据移出输入框或者树形结构弹窗时, 让树形结构弹窗消失*/
        stopOverflowEvent (e) {
            this.ishowTree = !this.ishowTree;
            let _this = this;
            document.onclick=function(){
                _this.ishowTree = false;
                _this.ishowTreeImplementationUnit = false;
            };
            e.stopPropagation();
        },

        /*弹出导出提示遮罩*/
        exportData () {
            this.onSelect()
            setTimeout(() => {
                this.vueDialogLoad('您是否确定导出表格中查询出的所有数据？', '提示', this.exportPlanData);
            }, 1500)
        },

        /*导出Excel*/
        exportPlanData () {
            this.searchPlanName1 = this.searchPlanName;
            this.organCodes1 = this.organCodes;
            this.searchPlanYear1 = this.searchPlanYear;
            if(!!this.organCodes1){
                this.orgCodeStr = this.organCodes1;
            }
            axios.post(context + '/plan/query/download', {
                planYear: this.searchPlanYear,
                singleId: this.organCodes,
                orgId: this.orgId,
                planName: this.searchPlanName,
                planType: this.searchPlanType,
                endTime: this.endTime1,
                startTime: this.startTime1,
                customSortProp: this.customSortProp,
                customSortOrder: this.customSortOrder,
                implementationOrgId: this.searchOrgImplementationUnitCode,
                majorType: this.searchMajorType
            }).then(res => {
                this.downLoadloading.close()
                if (res.data.resultCode === 200) {
                    let url = context + '/plan/query/downLoadAuditPlanExcel?pathURL=' + res.data.data.pathURL
                    window.location.href = url;
                    // this.$message.success(res.data.resultMsg)
                    vueDialog(res.data.resultMsg,"提示","success",this,function(){});
                }
            }).catch(res => {
                // this.$message.error(res.data.resultMsg);
                vueDialog(res.data.resultMsg,"提示","error",this,function(){});
            })
        },

        /*条件查询*/
        queryData () {
            this.planListLoading = true
            axios.post(context + '/plan/query/getPlanListByTurnPage', {
                begNum: this.begNum,
                fetchNum: this.fetchNum,
                planYear: this.searchPlanYear1,
                singleId: this.organCodes1,
                orgId: this.orgId,
                planName: this.searchPlanName1,
                planType: this.searchPlanType1,
                endTime: this.endTime1,
                startTime: this.startTime1,
                customSortProp: this.customSortProp,
                customSortOrder: this.customSortOrder,
                implementationOrgId: this.searchOrgImplementationUnitCode1,
                majorType: this.searchMajorType1,
            }).then(res => {
                if (!!res.data.data.data && res.data.data.data.length > 0) {
                    for(let i = 0; i < res.data.data.data.length; i++){
                        res.data.data.data[i].btnShow = true;
                        res.data.data.data[i].inputShow = false;
                    }
                    this.planListData = res.data.data.data;
                    this.totalPage = res.data.data.totalNum;

                }else {
                    this.planListData = []
                }
                this.planListLoading = false
            }).catch(res => {
                this.planListLoading = false
                // this.$message.error(res.data.data.resultMsg)
                vueDialog(res.data.data.resultMsg,"提示","error",this,function(){});
            })
        },

        /*查询*/
        onSelect () {
            if (!!this.searchOrgImplementationUnit) {
                //searchOrgStr searchPlanType
                if (!this.searchOrgStr || !this.searchPlanType) {
                    vueDialog('筛选计划实施单位的时候，审计计划类别和计划制定单位不可以为空',"提示","warning",this,function(){});
                    return
                }
            }

            this.searchPlanName1 = this.searchPlanName;
            this.organCodes1 = this.organCodes;
            this.searchPlanYear1 = this.searchPlanYear;
            this.searchOrgImplementationUnitCode1 = this.searchOrgImplementationUnitCode
            this.searchPlanType1 = this.searchPlanType
            this.searchMajorType1 = this.searchMajorType
            this.startTime1 = this.startTime
            this.endTime1 = this.endTime
            this.changeValue();
            this.begNum = 1;
            this.currentPage = 1;
            this.queryData();
        },

        /*重置*/
        resetSelect (){
            //重置树
            this.$refs.dataTree.setCheckedNodes([]);//清空选中节点
            this.organCodes = this.orgId;//清空机构ID集合，恢复为当前机构ID
            this.organCodes1 = this.orgId;//清空机构ID集合，恢复为当前机构ID
            this.searchOrgStr = orgName;
            this.searchPlanName = '';
            this.searchPlanName1 = '';
            this.searchPlanYear = this.getCurrentYear();//获取当前年份
            this.searchPlanYear1 = this.searchPlanYear;
            this.begNum = 1;//恢复数据库查询的起始位置
            this.currentPage = 1;//恢复当前页码
            this.searchPlanType = planTypeInit
            this.searchPlanType1 = planTypeInit
            // this.startEndAnnual = []
            this.endTime = ''
            this.endTime1 = ''
            this.startTime = ''
            this.startTime1 = ''
            this.searchOrgImplementationUnitCode = '';
            this.searchOrgImplementationUnitCode1 = '';
            this.searchMajorType = '';
            this.searchMajorType1 = '';
            this.searchOrgImplementationUnit = ''
            this.queryData();//执行查询
        },

        /*获取当前年份*/
        getCurrentYear (){
            let date = new Date();
            return date.getFullYear().toString();
        },

        /*改变表格显示条数执行*/
        handleSizeChange (val) {
            this.organCodes1 = this.organCodes;
            this.pageSize = val;
            this.fetchNum = val;
            this.begNum = 1;
            this.currentPage = 1;
            this.queryData();
        },

        /*改变当前页执行*/
        handleCurrentChange (val) {
            this.organCodes1 = this.organCodes;
            //返回值 当前页码
            this.currentPage = val;
            this.begNum = this.fetchNum * (this.currentPage - 1) + 1;
            this.queryData();
        },

        /*点击上一页执行*/
        prevPage (val) {
            this.organCodes1 = this.organCodes;
            //返回值 当前页码
            this.currentPage = val;
            this.begNum = this.fetchNum * (this.currentPage - 1) + 1;
            this.queryData();
        },

        /*点击下一页执行*/
        nextPage (val) {
            this.organCodes1 = this.organCodes;
            //返回值 当前页码
            this.currentPage = val;
            this.begNum = this.fetchNum * (this.currentPage - 1) + 1;
            this.queryData();
        },

        /*序号Index翻页递增*/
        indexMethod (index){
            return (this.currentPage - 1) * this.fetchNum + index + 1;
        },

        /*关闭对话框*/
        dialogCloseView () {
            //关闭打开的对话框
            this.viewDialog = false;
        },

        /*点击查看*/
        viewRow (row) {
            let planId = row.pkPlan;
            let tabName = '查看计划';
            parent.window.mainMenu.addTab(tabName, "/plan/query/toPlanDetail?planId=" + planId);
        },

        /*弹出框封装*/
        vueDialogLoad (messageStr, messageTitle, callback){
            //做延迟处理:防止页面第二次闪出弹窗框
            let _this = this;
            setTimeout(()=>{
                _this.$confirm(messageStr, messageTitle, {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                }).then(() => {
                    _this.downLoadloading = _this.$loading({
                        lock: true,
                        text: '数据导出中...',
                        spinner: 'el-icon-loading',
                        background: 'rgba(0, 0, 0, 0.7)'
                    });
                    setTimeout(()=>{
                        callback();
                    },500)
                }).catch(() => {});
            },500)
        },

        //跳转到计划导图页面
        showPlanMindMap(row) {
            let tabName = '查看计划分解情况';
            parent.window.mainMenu.addTab(tabName, '/plan/analyze/init?planId=' + row.pkPlan);
        },

        //跳转到我的分解导图页面
        myResolve(row) {
            let tabName = '查看计划（项目）分解下达情况';
            parent.window.mainMenu.addTab(tabName, '/plan/issuedView/toPlanIssuedViewPage');
        },
    }
});