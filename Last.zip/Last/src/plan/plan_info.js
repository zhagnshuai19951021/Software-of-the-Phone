new Vue({
    el: '#projectInfoPage',
    data: function () {
        return {
        }
    },
    methods: {
        created() {
        },
        doReturn() {
            window.location.href=listInfoUrl;
        }
    }
});