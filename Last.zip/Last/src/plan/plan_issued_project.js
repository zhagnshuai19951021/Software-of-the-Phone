new Vue({
    el: '#planShow',
    data: function () {
        return {
            orgId:orgId,//登录机构
            context:context,//项目的相对路径配置
            planListData:[],//表格的list数据
            currentPage: 1,//当前页码
            fetchNum: 10,//当前页显示条数
            totalPage: '',//数据总条数
            begNum:1,//分页数据:数据库查询的起始位置
            downLoadloading:'',//导出遮罩层
            planListLoading: false,
            selectionPlanIdsStr: selectionPlanIdsStr
        }
    },

    watch:{},

    /*钩子函数：页面渲染前执行*/
    created () {
        this.queryData();
    },

    /*钩子函数：页面加载完成后执行*/
    mounted () {
        document.getElementById("planShow").style.display='block';//页面加载优化
        this.windowResizeEvent(this.reSize);
    },

    methods: {
        /*监听元素大小改变事件*/
        windowResizeEvent (callback) {
            let resizeTimer = null;
            window.onresize = () => {
                if(resizeTimer === null) {
                    resizeTimer = setTimeout(() => {
                        resizeTimer = null;
                        callback();
                    }, 200);
                }
            }
        },

        /*元素大小改变*/
        reSize() {
            this.$nextTick(() => {
                var tableW = this.$refs.planListTb1.$el.offsetWidth;
            })
        },

        /*弹出导出提示遮罩*/
        exportData () {
            this.queryData()
            setTimeout(() => {
                this.vueDialogLoad('您是否确定导出表格中所有数据？', '提示', this.exportPlanData);
            }, 1500)
        },

        /*导出Excel*/
        exportPlanData () {
            axios.post(context + '/plan/query/exportPlanIssuedProject', {
                selectionPlanIdsStr: this.selectionPlanIdsStr
            }).then(res => {
                this.downLoadloading.close()
                if (res.data.resultCode === 200) {
                    let url = context + '/plan/query/downLoadPlanIssuedProjectExcel?pathURL=' + res.data.data.pathURL
                    window.location.href = url;
                    vueDialog(res.data.resultMsg,"提示","success",this,function(){});
                }
            }).catch(res => {
                vueDialog(res.data.resultMsg,"提示","error",this,function(){});
            })
        },

        /*查询*/
        queryData () {
            this.planListLoading = true
            axios.post(context + '/plan/query/queryPlanIssuedProject', {
                begNum: this.begNum,
                fetchNum: this.fetchNum,
                selectionPlanIdsStr: this.selectionPlanIdsStr
            }).then(res => {
                console.log(res)

                if (!!res.data.data.data && res.data.data.data.length > 0) {
                    this.planListData = res.data.data.data;
                    this.totalPage = res.data.data.totalNum;
                }else {
                    this.planListData = []
                }
                this.planListLoading = false
            }).catch(res => {
                vueDialog(res.data.data.resultMsg,"提示","error",this,function(){});
            })
        },

        /*改变表格显示条数执行*/
        handleSizeChange (val) {
            this.organCodes1 = this.organCodes;
            this.pageSize = val;
            this.fetchNum = val;
            this.begNum = 1;
            this.currentPage = 1;
            this.queryData();
        },

        /*改变当前页执行*/
        handleCurrentChange (val) {
            this.organCodes1 = this.organCodes;
            //返回值 当前页码
            this.currentPage = val;
            this.begNum = this.fetchNum * (this.currentPage - 1) + 1;
            this.queryData();
        },

        /*点击上一页执行*/
        prevPage (val) {
            this.organCodes1 = this.organCodes;
            //返回值 当前页码
            this.currentPage = val;
            this.begNum = this.fetchNum * (this.currentPage - 1) + 1;
            this.queryData();
        },

        /*点击下一页执行*/
        nextPage (val) {
            this.organCodes1 = this.organCodes;
            //返回值 当前页码
            this.currentPage = val;
            this.begNum = this.fetchNum * (this.currentPage - 1) + 1;
            this.queryData();
        },

        /*序号Index翻页递增*/
        indexMethod (index){
            return (this.currentPage - 1) * this.fetchNum + index + 1;
        },

        /*弹出框封装*/
        vueDialogLoad (messageStr, messageTitle, callback){
            //做延迟处理:防止页面第二次闪出弹窗框
            let _this = this;
            setTimeout(()=>{
                _this.$confirm(messageStr, messageTitle, {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                }).then(() => {
                    _this.downLoadloading = _this.$loading({
                        lock: true,
                        text: '数据导出中...',
                        spinner: 'el-icon-loading',
                        background: 'rgba(0, 0, 0, 0.7)'
                    });
                    setTimeout(()=>{
                        callback();
                    },500)
                }).catch(() => {});
            },500)
        }
    }
});