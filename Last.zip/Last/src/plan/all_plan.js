new Vue({
    el: '#load_planMap',
    data: function () {
        return {
            downLoadloading: '',
            //侧栏树的数据
            asideTreeData: [],
            defaultProps: {
                children: 'children',
                label: 'label'
            },
            planData: [],	//表格信息
            orgId:orgCode,
            orgName:orgName,
            userTableH: 300,
            ctx:ctx,
            tableLoading: false,
            emptyText: ' ',
        }
    },
    created: function () {
        //this.getTabelData();
        this.tableLoading = true;
        this.resetSize();
    },
    mounted: function () {
        this.myResolveLoadData();
        this.windowResizeEvent(this.resetSize);
    },
    methods: {
        myResolveLoadData() {
            var url = ctx+"/plan/analyze/myResolveLoadData";
            var that = this;
            $.ajax({
                type: 'post',
                dataType: 'json',
                contentType: 'application/json;charset=UTF-8',
                url: url,
                success: function(data) {
                    if (data.resultCode == 200) {
                        planData = data.data;
                        that.getTabelData();
                        that.tableLoading = false;
                    } else {
                        that.tableLoading = false;
                    }
                }
            });
        },
        //获取表格数据
        getTabelData(){

            this.planData = this.dealData(planData, '0', 1);
        },
        dealData(res, parentId, level) {
            let newArray = [];
            res.forEach((v, i) => {
                let newObj = {};
                for(let attr in v){
                    if(attr != 'children'){
                        newObj[attr] = v[attr];
                    }
                }
                newObj.parentId = parentId;
                <!--newObj.selected = false;-->
                newObj.level = level;
                if(newObj.level < 2){
                    newObj.visible = true;
                    newObj.hiddenByPro = true;
                }else{
                    newObj.visible = false;
                    newObj.hiddenByPro = false;
                }
                if(v.children && v.children.length > 0){
                    newObj.hasChildren = true;
                    newObj.showChildren = false;
                    newObj.ctrl = false;
                }else{
                    newObj.ctrl = true;
                }
                newArray.push(newObj);
                if(v.children && v.children.length > 0){
                    let subItemArray = this.dealData(v.children, v.id, level+1);
                    newArray = newArray.concat(subItemArray);
                }
            })
            return newArray;
        },
        rowClassNameHandler({row, rowIndex}) {
            let className = 'tr' + row.parentId;
            if(row.parentId !== '0' && (row['visible'] !== true || row['hiddenByPro'] === true)){
                className += ' hiddenRow';
            }
            return className;
        },
        onExpand(row) {
            let isShowChildren = !row['showChildren'];
            row['showChildren'] = isShowChildren;
            this.loadAllSubItem(row, true, isShowChildren);
            this.resetSize();
        },
        loadAllSubItem(item, isFirstNode, isShowChildren) {
            let dataArray = [];
            for(let i = 0; i < this.planData.length; i++) {
                let tempItem = this.planData[i];
                if(tempItem.parentId == item.id){
                    if(isFirstNode) {
                        tempItem['visible'] = !tempItem['visible'];
                    }
                    tempItem['hiddenByPro'] = !isShowChildren;
                    dataArray.push(tempItem);
                    let subItemArray = this.loadAllSubItem(
                        tempItem,
                        false,
                        isShowChildren
                    );
                    dataArray = dataArray.concat(subItemArray)
                }
            }
            return dataArray;
        },
        windowResizeEvent (callback) {
            let resizeTimer = null;
            window.onresize =  () => {
                if(resizeTimer === null) {
                    resizeTimer = setTimeout( () => {
                        resizeTimer = null;
                        callback();
                    }, 200);
                }
            }
        },
        resetSize(){
            this.$nextTick(()=>{
                let clientH = document.body.clientHeight;
                this.userTableH = clientH-40;
            })
        },

        toPlanDetails(val) {
            let tabName = '查看计划';
            parent.window.mainMenu.addTab(tabName, '/plan/query/toPlanDetail?planId=' + val);
        },

        viewProject : function(val){
            var tabName = '审计项目查看';
            var tabUrl = "/project/projectInfo?pkId=" + val;
            parent.window.mainMenu.addTab(tabName,tabUrl);
        },

        doExport: function() {
            var that=this;
            this.vueDialogLoad("您是否确定导出表格中查询出的所有数据？","提示",that.exportData);
        },

        exportData : function() {
            var url = ctx+"/project/exportAllPlan";
            var data = {
                "planId": this.planId
            };
            var that = this;
            $.ajax({
                type: "post",
                dataType: "json",
                url: url,
                contentType: "application/json;charset=UTF-8",
                data: JSON.stringify(data),
                success: function(data) {
                    console.log('sadf',data)
                    that.downLoadloading.close();
                    if(data.resultCode==200){
                        // that.$message.success(data.resultMsg);
                        vueDialog(data.resultMsg,"提示","success",that,function(){
                            var url= ctx+"/project/downLoadAllPlanExcel?pathURL="+data.data.pathURL;
                            window.location.href = url;
                        });

                    }else{
                        // that.$message.error(resp.resultMsg);
                        vueDialog(res.resultMsg,"提示","error",that,function(){});
                    }
                }
            });
        },

        //弹出框封装
        vueDialogLoad(messageStr,messageTitle,callback){
            //做延迟处理:防止页面第二次闪出弹窗框
            var that=this;
            setTimeout(()=>{
                this.$confirm(messageStr, messageTitle, {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                }).then(() => {

                    that.downLoadloading = that.$loading({
                        lock: true,
                        text: '数据导出中...',
                        spinner: 'el-icon-loading',
                        background: 'rgba(0, 0, 0, 0.7)'
                    });

                    setTimeout(()=>{
                        callback();
                    },500)
                }).catch(() => {

                });
            },500)

        },
    }
});