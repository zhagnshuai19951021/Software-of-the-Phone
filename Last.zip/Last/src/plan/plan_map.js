new Vue({
    el: '#load_planMap',
    data: function () {
        return {
            downLoadloading: '',
            //侧栏树的数据
            asideTreeData: [],
            defaultProps: {
                children: 'children',
                label: 'label'
            },
            planData: [],	//表格信息
            newPlanData: [],
            orgId:orgCode,
            planId:planId,
            planName:planName,
            userTableH: 300,
            ctx:ctx,
            tableLoading: false,
        }
    },
    created: function () {
        this.orderData(planData);
        this.dealData1(planData);
        this.getTabelData();
        this.resetSize();
    },
    mounted: function () {
        this.windowResizeEvent(this.resetSize);
    },
    methods: {
        //获取表格数据
        getTabelData(){
            this.planData = this.dealData(planData, '0', 1);
        },
        dealData(res, parentId, level) {
            let newArray = [];
            res.forEach((v, i) => {
                let newObj = {};
                for(let attr in v){
                    if(attr != 'children'){
                        newObj[attr] = v[attr];
                    }
                }
                newObj.parentId = parentId;
                <!--newObj.selected = false;-->
                newObj.level = level;
                if(newObj.level < 2){
                    newObj.visible = true;
                    newObj.hiddenByPro = true;
                }else{
                    newObj.visible = false;
                    newObj.hiddenByPro = false;
                }
                if(v.children && v.children.length > 0){
                    newObj.hasChildren = true;
                    newObj.showChildren = false;
                    newObj.ctrl = false;
                }else{
                    newObj.ctrl = true;
                }
                newArray.push(newObj);
                if(v.children && v.children.length > 0){
                    let subItemArray = this.dealData(v.children, v.id, level+1);
                    newArray = newArray.concat(subItemArray);
                }
            })
            return newArray;
        },

        dealData1(data){
            console.log("1:"+data);
            if(data!=null&&data!=undefined&&data!=''){
                for(var i=0;i<data.length;i++){
                    if(data[i].isChildNode!=2&&data[i].orgForm=="OT10"){
                        data[i].label = i+1+"."+data[i].label;
                    }
                    if(data[i].projectInfoModelList!=null&&data[i].projectInfoModelList!=''&&data[i].projectInfoModelList!=undefined){
                        for(var j=0;j<data[i].projectInfoModelList.length;j++){
                            if(data[i].projectInfoModelList[j].projectName!=null&&data[i].projectInfoModelList[j].projectName!=''&&data[i].projectInfoModelList[j].projectName!=undefined){
                                data[i].projectInfoModelList[j].projectName = j+1+". "+data[i].projectInfoModelList[j].projectName;
                            }
                        }
                    }
                    if(data[i].children!=null&&data[i].children!=undefined&&data[i].children!=''){
                        this.dealData1(data[i].children);
                    }
                }
             }
        },

        orderData(data){
            //console.log("1:"+planData);
            if(data!=null&&data!=undefined&&data!=''){
                for(var i=0;i<data.length;i++){
                    var newArrayChildren=[];
                    if(data[i].children!=null&&data[i].children!=''&&data[i].children!=undefined){
                        if(data[i].children.length==2){
                            if(data[i].children[0].orgType==3&&data[i].children[1].orgType==0){
                                newArrayChildren.push(data[i].children[1]);
                                newArrayChildren.push(data[i].children[0]);
                                data[i].children = newArrayChildren;
                            }
                        }
                    }
                }
             }
        },

        rowClassNameHandler({row, rowIndex}) {
            let className = 'tr' + row.parentId;
            if(row.parentId !== '0' && (row['visible'] !== true || row['hiddenByPro'] === true)){
                className += ' hiddenRow';
            }
            return className;
        },
        onExpand(row) {
            let isShowChildren = !row['showChildren'];
            row['showChildren'] = isShowChildren;
            this.loadAllSubItem(row, true, isShowChildren);
            this.resetSize();
        },
        loadAllSubItem(item, isFirstNode, isShowChildren) {
            let dataArray = [];
            for(let i = 0; i < this.planData.length; i++) {
                let tempItem = this.planData[i];
                if(tempItem.parentId == item.id){
                    if(isFirstNode) {
                        tempItem['visible'] = !tempItem['visible'];
                    }
                    tempItem['hiddenByPro'] = !isShowChildren;
                    dataArray.push(tempItem);
                    let subItemArray = this.loadAllSubItem(
                        tempItem,
                        false,
                        isShowChildren
                    );
                    dataArray = dataArray.concat(subItemArray)
                }
            }
            return dataArray;
        },
        maintenance(scope){
            <!--机构id,用于决定添加的角色,以及机构的级别-->
            //跳转
            this.orgId = scope.row.id;
            var url = '/system/user/upholduser?orgId='+this.orgId+'&pmc=004&oac=003';
            tabName = '人员维护';
            parent.window.mainMenu.addTab(tabName,url);
        },
        windowResizeEvent (callback) {
            let resizeTimer = null;
            window.onresize =  () => {
                if(resizeTimer === null) {
                    resizeTimer = setTimeout( () => {
                        resizeTimer = null;
                        callback();
                    }, 200);
                }
            }
        },
        resetSize(){
            this.$nextTick(()=>{
                let clientH = document.body.clientHeight;
                this.userTableH = clientH-40;
            })
        },

        toPlanDetails(val) {
            let tabName = '查看计划';
            parent.window.mainMenu.addTab(tabName, '/plan/query/toPlanDetail?planId=' + val);
        },

        viewProject : function(val){
            var tabName = '审计项目查看';
            var tabUrl = "/project/projectInfo?pkId=" + val;
            parent.window.mainMenu.addTab(tabName,tabUrl);
        },

        doExport: function() {
            var that=this;
            this.vueDialogLoad("您是否确定导出表格中查询出的所有数据？","提示",that.exportData);
        },

        exportData : function() {
            var url = ctx+"/project/exportPlanMap";
            var data = {
                "planId": this.planId,
                "planName": this.planName
            };
            var that = this;
            $.ajax({
                type: "post",
                dataType: "json",
                url: url,
                contentType: "application/json;charset=UTF-8",
                data: JSON.stringify(data),
                success: function(data) {
                    that.downLoadloading.close();
                    if(data.resultCode==200){
                        // that.$message.success(data.resultMsg);
                        vueDialog(data.resultMsg,"提示","success",that,function(){
                            var url= ctx+"/project/downLoadPlanMapExcel?pathURL="+data.data.pathURL;
                            window.location.href = url;
                        });

                    }else{
                        // that.$message.error(resp.resultMsg);
                        vueDialog(resp.resultMsg,"提示","error",that,function(){});
                    }
                }
            });
        },



        //弹出框封装
        vueDialogLoad(messageStr,messageTitle,callback){
            //做延迟处理:防止页面第二次闪出弹窗框
            var that=this;
            setTimeout(()=>{
                this.$confirm(messageStr, messageTitle, {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                }).then(() => {

                    that.downLoadloading = that.$loading({
                        lock: true,
                        text: '数据导出中...',
                        spinner: 'el-icon-loading',
                        background: 'rgba(0, 0, 0, 0.7)'
                    });

                    setTimeout(()=>{
                        callback();
                    },500)
                }).catch(() => {

                });
            },500)

        },
    }
});